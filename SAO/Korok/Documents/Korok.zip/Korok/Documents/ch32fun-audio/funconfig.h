#ifndef _FUNCONFIG_H
#define _FUNCONFIG_H

#define FUNCONF_SYSTICK_USE_HCLK 1

#endif
